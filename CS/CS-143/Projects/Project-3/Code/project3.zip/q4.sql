SELECT COUNT(DISTINCT place_id)
FROM Affiliated
WHERE name = 'University of California'
