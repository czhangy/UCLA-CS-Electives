import { defs, tiny } from "./examples/common.js";

const {
	Vector,
	Vector3,
	vec,
	vec3,
	vec4,
	color,
	hex_color,
	Matrix,
	Mat4,
	Light,
	Shape,
	Material,
	Scene,
} = tiny;

class Cube extends Shape {
	constructor() {
		super("position", "normal");
		this.arrays.position = Vector3.cast(
			[-1, -1, -1],
			[1, -1, -1],
			[-1, -1, 1],
			[1, -1, 1],
			[1, 1, -1],
			[-1, 1, -1],
			[1, 1, 1],
			[-1, 1, 1],
			[-1, -1, -1],
			[-1, -1, 1],
			[-1, 1, -1],
			[-1, 1, 1],
			[1, -1, 1],
			[1, -1, -1],
			[1, 1, 1],
			[1, 1, -1],
			[-1, -1, 1],
			[1, -1, 1],
			[-1, 1, 1],
			[1, 1, 1],
			[1, -1, -1],
			[-1, -1, -1],
			[1, 1, -1],
			[-1, 1, -1]
		);
		this.arrays.normal = Vector3.cast(
			[0, -1, 0],
			[0, -1, 0],
			[0, -1, 0],
			[0, -1, 0],
			[0, 1, 0],
			[0, 1, 0],
			[0, 1, 0],
			[0, 1, 0],
			[-1, 0, 0],
			[-1, 0, 0],
			[-1, 0, 0],
			[-1, 0, 0],
			[1, 0, 0],
			[1, 0, 0],
			[1, 0, 0],
			[1, 0, 0],
			[0, 0, 1],
			[0, 0, 1],
			[0, 0, 1],
			[0, 0, 1],
			[0, 0, -1],
			[0, 0, -1],
			[0, 0, -1],
			[0, 0, -1]
		);
		this.indices.push(
			0,
			1,
			2,
			1,
			3,
			2,
			4,
			5,
			6,
			5,
			7,
			6,
			8,
			9,
			10,
			9,
			11,
			10,
			12,
			13,
			14,
			13,
			15,
			14,
			16,
			17,
			18,
			17,
			19,
			18,
			20,
			21,
			22,
			21,
			23,
			22
		);
	}
}

class Cube_Outline extends Shape {
	constructor() {
		super("position", "color");
		this.arrays.position = Vector3.cast(
			[1, 1, 1],
			[-1, 1, 1],
			[1, 1, 1],
			[1, -1, 1],
			[-1, -1, 1],
			[-1, 1, 1],
			[-1, -1, 1],
			[1, -1, 1],
			[1, 1, -1],
			[-1, 1, -1],
			[1, 1, -1],
			[1, -1, -1],
			[-1, -1, -1],
			[-1, 1, -1],
			[-1, -1, -1],
			[1, -1, -1],
			[1, 1, 1],
			[1, 1, -1],
			[1, -1, 1],
			[1, -1, -1],
			[-1, 1, 1],
			[-1, 1, -1],
			[-1, -1, 1],
			[-1, -1, -1]
		);
		this.arrays.color = Vector3.cast(
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1],
			[255, 255, 255, 1]
		);
		this.indices = false;
	}
}

class Cube_Single_Strip extends Shape {
	constructor() {
		super("position", "normal");
		this.arrays.position = Vector3.cast(
			[1, 1, 1],
			[1, 1, -1],
			[1, -1, 1],
			[1, -1, -1],
			[-1, 1, 1],
			[-1, 1, -1],
			[-1, -1, 1],
			[-1, -1, -1]
		);
		this.arrays.normal = Vector3.cast(
			[1, 1, 1],
			[1, 1, -1],
			[1, -1, 1],
			[1, -1, -1],
			[-1, 1, 1],
			[-1, 1, -1],
			[-1, -1, 1],
			[-1, -1, -1]
		);
		this.indices.push(
			6,
			4,
			0,
			0,
			1,
			4,
			4,
			5,
			1,
			1,
			3,
			5,
			5,
			7,
			3,
			3,
			1,
			2,
			2,
			1,
			0,
			0,
			2,
			6,
			6,
			7,
			2,
			2,
			3,
			7,
			7,
			5,
			4,
			4,
			6,
			7
		);
	}
}

class Base_Scene extends Scene {
	constructor() {
		super();
		this.hover = this.swarm = false;
		this.shapes = {
			cube: new Cube(),
			outline: new Cube_Outline(),
			strip: new Cube_Single_Strip(),
		};

		this.materials = {
			plastic: new Material(new defs.Phong_Shader(), {
				ambient: 0.4,
				diffusivity: 0.6,
				color: hex_color("#ffffff"),
			}),
		};
		this.white = new Material(new defs.Basic_Shader());
	}

	display(context, program_state) {
		if (!context.scratchpad.controls) {
			this.children.push(
				(context.scratchpad.controls = new defs.Movement_Controls())
			);
			program_state.set_camera(Mat4.translation(5, -10, -30));
		}
		program_state.projection_transform = Mat4.perspective(
			Math.PI / 4,
			context.width / context.height,
			1,
			100
		);
		const light_position = vec4(0, 5, 5, 1);
		program_state.lights = [
			new Light(light_position, color(1, 1, 1, 1), 1000),
		];
	}
}

export class Assignment2 extends Base_Scene {
	constructor() {
		super();
		// Define attibutes
		this.numBoxes = 8;
		this.period = 3;
		this.maxRotation = 0.05 * Math.PI;
		this.scaling = 1.5;
		// Define flags
		this.still = false;
		this.outline = false;
		// Random colors
		this.colors = [];
		this.set_colors();
	}

	set_colors() {
		this.colors = [];
		// Generate a random color for each shape
		for (let i = 0; i < this.numBoxes; i++) {
			this.colors.push(
				color(Math.random(), Math.random(), Math.random(), 1.0)
			);
		}
	}

	make_control_panel() {
		this.key_triggered_button("Change Colors", ["c"], this.set_colors);
		this.key_triggered_button("Outline", ["o"], () => {
			this.outline = !this.outline;
		});
		this.key_triggered_button("Sit still", ["m"], () => {
			this.still = !this.still;
		});
	}

	draw_box(context, program_state, model_transform, boxNum) {
		// Calculate rotation angle
		const t = (this.t = program_state.animation_time / 1000);
		const freq = (2 * Math.PI) / this.period;
		const amplitude = this.maxRotation / 2;
		let rot = 0;
		if (boxNum !== 0) {
			if (this.still) rot = this.maxRotation;
			else rot = amplitude + amplitude * Math.sin(freq * t);
		}
		// Positioning + Rotation + Scaling
		model_transform = model_transform
			.times(Mat4.translation(1, this.scaling + rot, 0))
			.times(Mat4.rotation(rot, 0, 0, 1))
			.times(Mat4.translation(-1, this.scaling + rot, 0))
			.times(Mat4.scale(1, this.scaling, 1));
		// Draw the box
		if (this.outline) {
			this.shapes.outline.draw(
				context,
				program_state,
				model_transform,
				this.white,
				"LINES"
			);
		} else if (boxNum % 2 === 1) {
			this.shapes.strip.draw(
				context,
				program_state,
				model_transform,
				this.materials.plastic.override({ color: this.colors[boxNum] }),
				"TRIANGLE_STRIP"
			);
		} else {
			this.shapes.cube.draw(
				context,
				program_state,
				model_transform,
				this.materials.plastic.override({ color: this.colors[boxNum] })
			);
		}
		// Re-scale
		model_transform = model_transform.times(
			Mat4.scale(1, 1 / this.scaling, 1)
		);
		return model_transform;
	}

	display(context, program_state) {
		// Initialization
		super.display(context, program_state);
		let model_transform = Mat4.identity();
		// Draw all 8 boxes
		for (let i = 0; i < this.numBoxes; i++) {
			model_transform = this.draw_box(
				context,
				program_state,
				model_transform,
				i
			);
		}
	}
}
