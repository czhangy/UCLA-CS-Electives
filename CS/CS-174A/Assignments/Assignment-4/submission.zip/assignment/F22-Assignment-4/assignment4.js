import { defs, tiny } from "./examples/common.js";

const {
	Vector,
	Vector3,
	vec,
	vec3,
	vec4,
	color,
	hex_color,
	Shader,
	Matrix,
	Mat4,
	Light,
	Shape,
	Material,
	Scene,
	Texture,
} = tiny;

const { Cube, Axis_Arrows, Textured_Phong } = defs;

export class Assignment4 extends Scene {
	constructor() {
		super();

		// Constants
		this.black = "#000000";
		this.ambient = 1;
		this.xPos = 2;
		this.imageZoom = 0.5;
		this.rpm = {
			box1: 20,
			box2: 30,
		};

		// Definitions
		this.shapes = {
			box1: new Cube(),
			box2: new Cube(),
			axis: new Axis_Arrows(),
		};
		this.materials = {
			stars: new Material(new Texture_Rotate(), {
				color: hex_color(this.black),
				ambient: this.ambient,
				texture: new Texture("assets/stars.png", "NEAREST"),
			}),
			earth: new Material(new Texture_Scroll_X(), {
				color: hex_color(this.black),
				ambient: this.ambient,
				texture: new Texture(
					"assets/earth.gif",
					"LINEAR_MIPMAP_LINEAR"
				),
			}),
		};
		this.initial_camera_location = Mat4.look_at(
			vec3(0, 10, 20),
			vec3(0, 0, 0),
			vec3(0, 1, 0)
		);

		// State
		this.model_transforms = {
			box1: Mat4.identity().times(Mat4.translation(-this.xPos, 0, 0)),
			box2: Mat4.identity().times(Mat4.translation(this.xPos, 0, 0)),
		};
		this.rotationActive = false;

		// Helper function
		this.convertRPM = (rpm) => rpm * (1 / 60) * 2 * Math.PI;
	}

	make_control_panel() {
		this.key_triggered_button(
			"Toggle rotation",
			["c"],
			() => (this.rotationActive = !this.rotationActive)
		);
	}

	display(context, program_state) {
		if (!context.scratchpad.controls) {
			this.children.push(
				(context.scratchpad.controls = new defs.Movement_Controls())
			);
			program_state.set_camera(Mat4.translation(0, 0, -8));
		}

		program_state.projection_transform = Mat4.perspective(
			Math.PI / 4,
			context.width / context.height,
			1,
			100
		);

		const light_position = vec4(10, 10, 10, 1);
		program_state.lights = [
			new Light(light_position, color(1, 1, 1, 1), 1000),
		];

		// Calculate time delta
		let dt = program_state.animation_delta_time / 1000;

		// Adjust texture for box #2
		this.shapes.box2.arrays.texture_coord =
			this.shapes.box2.arrays.texture_coord.map((x) =>
				x.times(1 / this.imageZoom)
			);

		// Rotate boxes
		if (this.rotationActive) {
			// Calculate rotation deltas
			let dr1 = this.convertRPM(this.rpm.box1) * dt;
			let dr2 = this.convertRPM(this.rpm.box2) * dt;
			// Apply rotations
			this.model_transforms.box1 = this.model_transforms.box1.times(
				Mat4.rotation(dr1, 1, 0, 0)
			);
			this.model_transforms.box2 = this.model_transforms.box2.times(
				Mat4.rotation(dr2, 0, 1, 0)
			);
		}

		// Draw box #1
		this.shapes.box1.draw(
			context,
			program_state,
			this.model_transforms.box1,
			this.materials.stars
		);

		// Draw box #2
		this.shapes.box2.draw(
			context,
			program_state,
			this.model_transforms.box2,
			this.materials.earth
		);
	}
}

class Texture_Scroll_X extends Textured_Phong {
	fragment_glsl_code() {
		return (
			this.shared_glsl_code() +
			`
            varying vec2 f_tex_coord;
            uniform sampler2D texture;
            uniform float animation_time;
            void main(){
                // Scroll the texture
                float ds = mod(animation_time, 10.0) * 2.0;
                mat4 translation = mat4(
                    -1.0, 0.0, 0.0, 0.0,
                     0.0, 1.0, 0.0, 0.0,
                     0.0, 0.0, 1.0, 0.0,
                      ds, 0.0, 0.0, 1.0
                );
                vec4 coord = vec4(f_tex_coord, 0.0, 1.0) +
                     vec4(1.0, 1.0, 0.0, 0.0);
                coord = translation * coord;
                vec4 tex_color = texture2D(texture, coord.xy);
                
                // Draw the black box
                float x = mod(coord.x, 1.0);
                float y = mod(coord.y, 1.0);
                float outerDist = 0.15;
                float innerDist = 0.25;
                bool topEdge = x > outerDist && x < 1.0 - outerDist &&
                    y > 1.0 - innerDist && y < 1.0 - outerDist;
                bool bottomEdge = x > outerDist && x < 1.0 - outerDist &&
                    y > outerDist && y < innerDist;
                bool leftEdge = x > 1.0 - innerDist && x < 1.0 - outerDist &&
                    y > outerDist && y < 1.0 - outerDist;
                bool rightEdge = x > outerDist && x < innerDist &&
                    y > outerDist && y < 1.0 - outerDist;
                if (topEdge || bottomEdge || leftEdge || rightEdge) {
                    tex_color = vec4(0, 0, 0, 1);
                }

                // Default code
                if (tex_color.w < .01) discard;
                gl_FragColor = vec4((tex_color.xyz + shape_color.xyz) * ambient,
                    shape_color.w * tex_color.w); 
                gl_FragColor.xyz +=
                    phong_model_lights(normalize(N), vertex_worldspace);
            } `
		);
	}
}

class Texture_Rotate extends Textured_Phong {
	fragment_glsl_code() {
		return (
			this.shared_glsl_code() +
			`
            varying vec2 f_tex_coord;
            uniform sampler2D texture;
            uniform float animation_time;
            void main(){
                // Rotate the texture
                float dr = 0.5 * 3.141592653 * mod(animation_time, 4.0);
                mat4 rotation = mat4(
                    cos(dr), -sin(dr), 0.0, 0.0,
                    sin(dr),  cos(dr), 0.0, 0.0,
                        0.0,      0.0, 1.0, 0.0,
                        0.0,      0.0, 0.0, 1.0
                );
                vec4 coord = vec4(f_tex_coord, 0.0, 0.0) +
                     vec4(-0.5, -0.5, 0.0, 0.0);
                coord = rotation * coord + vec4(0.5, 0.5, 0.0, 0.0);
                vec4 tex_color = texture2D(texture, coord.xy);

                // Draw the black box
                float x = mod(coord.x, 1.0);
                float y = mod(coord.y, 1.0);
                float outerDist = 0.15;
                float innerDist = 0.25;
                bool topEdge = x > outerDist && x < 1.0 - outerDist &&
                    y > 1.0 - innerDist && y < 1.0 - outerDist;
                bool bottomEdge = x > outerDist && x < 1.0 - outerDist &&
                    y > outerDist && y < innerDist;
                bool leftEdge = x > 1.0 - innerDist && x < 1.0 - outerDist &&
                    y > outerDist && y < 1.0 - outerDist;
                bool rightEdge = x > outerDist && x < innerDist &&
                    y > outerDist && y < 1.0 - outerDist;
                if (topEdge || bottomEdge || leftEdge || rightEdge) {
                    tex_color = vec4(0, 0, 0, 1);
                }
                
                // Default code
                if (tex_color.w < .01) discard;
                gl_FragColor = vec4((tex_color.xyz + shape_color.xyz) * ambient,
                    shape_color.w * tex_color.w); 
                gl_FragColor.xyz +=
                    phong_model_lights(normalize(N), vertex_worldspace);
            } `
		);
	}
}
