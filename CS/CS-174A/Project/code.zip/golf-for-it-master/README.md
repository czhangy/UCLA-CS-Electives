# Golf For It

Our project proposal is a golf simulation game in third-person perspective of the ball, inspired by games such as Golf It! The goal is to hit the golf ball into the goal in as few strokes as possible. There will be obstacles that the player has to navigate around.
