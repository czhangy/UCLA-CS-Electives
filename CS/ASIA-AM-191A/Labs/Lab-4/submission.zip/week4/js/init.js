let latlng = [];
let markers = [];

// declare variables
const mapOptions = {
	zoom: 2,
	center: [40, -20],
};

// use the variables
const map = L.map("places-map").setView(mapOptions.center, mapOptions.zoom);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
	attribution:
		'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
}).addTo(map);

// create a function to add markers
function addMarker(lat, lng, title, q1, q2) {
	const marker = L.marker([lat, lng])
		.addTo(map)
		.bindPopup(
			`<h2>${title}</h2> <h3>Where did you get vaccinated?</h3><p>${q1}</p> <h3>Did you feel pressured to get vaccinated?</h3><p>${q2}</p>`
		);
	markers.push(marker);
}

function loadData(url) {
	Papa.parse(url, {
		header: true,
		download: true,
		complete: (results) => processData(results),
	});
}

function processData(results) {
	results.data.forEach((data) => {
		addMarker(
			data.lat,
			data.lng,
			data["Location"],
			data["Where did you get vaccinated?"],
			data["Did you ever feel pressured to get vaccinated? If so, how?"]
		);
		latlng.push({
			lat: data.lat,
			lng: data.lng,
		});
		createButtons(data.lat, data.lng, data["Location"]);
	});
	document
		.getElementById("random-button")
		.addEventListener("click", selectRandomMarker);
}

function selectRandomMarker() {
	if (latlng.length === 0) {
		return;
	}
	const randInd = Math.floor(Math.random() * latlng.length);
	map.flyTo([latlng[randInd].lat, latlng[randInd].lng]);
	markers[randInd].openPopup();
}

function createButtons(lat, lng, title) {
	const newButton = document.createElement("button"); // adds a new button
	newButton.id = "button" + title; // gives the button a unique id
	newButton.innerHTML = `<p>${title}</p>`; // gives the button a title
	newButton.setAttribute("lat", lat); // sets the latitude
	newButton.setAttribute("lng", lng); // sets the longitude
	newButton.addEventListener("click", function () {
		map.flyTo([lat, lng]); //this is the flyTo from Leaflet
	});
	document.getElementById("buttons").appendChild(newButton); //this adds the button to our page.
}

const dataURL =
	"https://docs.google.com/spreadsheets/d/e/2PACX-1vRMG0NuVI1oB9qEFttzh5RCWTc6rOxti_MJSD8FiLYx8wTG8ZhCCvHFWs63dUpNsG53Ep22leWfZmBJ/pub?output=csv";
loadData(dataURL);
