let latlng = [];
let markers = [];

// declare variables
const mapOptions = {
	zoom: 2,
	center: [40, -20],
};

// use the variables
const map = L.map("places-map").setView(mapOptions.center, mapOptions.zoom);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
	attribution:
		'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
}).addTo(map);

// create a function to add markers
function addMarker(lat, lng, title, q1, q2) {
	const marker = L.circleMarker([lat, lng], {
		color: randomRGB(),
	})
		.addTo(map)
		.bindPopup(
			`<h2>${title}</h2> <h3>Do you follow any professional sports? If so, what got you into them?</h3><p>${q1}</p> <h3>Do/did you play any organized sports? If so, what made you start playing?</h3><p>${q2}</p>`
		);
	markers.push(marker);
}

function loadData(url) {
	Papa.parse(url, {
		header: true,
		download: true,
		complete: (results) => processData(results),
	});
}

function processData(results) {
	results.data.forEach((data, i) => {
		addMarker(
			data.lat,
			data.lng,
			data["Location"],
			data[
				"Do you follow any professional sports? If so, what got you into them?"
			],
			data[
				"Do/did you play any organized sports? If so, what made you start playing?"
			]
		);
		latlng.push({
			lat: data.lat,
			lng: data.lng,
		});
		createButtons(data.lat, data.lng, data["Location"], i);
	});
	document
		.getElementById("random-button")
		.addEventListener("click", selectRandomMarker);
}

function selectRandomMarker() {
	if (latlng.length === 0) {
		return;
	}
	const randInd = Math.floor(Math.random() * latlng.length);
	map.flyTo([latlng[randInd].lat, latlng[randInd].lng]);
	markers[randInd].openPopup();
}

function createButtons(lat, lng, title, i) {
	const newButton = document.createElement("button"); // adds a new button
	newButton.id = "button" + title; // gives the button a unique id
	newButton.innerHTML = title; // gives the button a title
	newButton.setAttribute("lat", lat); // sets the latitude
	newButton.setAttribute("lng", lng); // sets the longitude
	newButton.addEventListener("click", function () {
		map.flyTo([lat, lng]); //this is the flyTo from Leaflet
		markers[i].openPopup();
		window.scrollTo({ top: 80, behavior: "smooth" });
	});
	document.getElementById("buttons").appendChild(newButton); //this adds the button to our page.
}

function randomRGB() {
	const r = Math.floor(Math.random() * 255) + 1;
	const g = Math.floor(Math.random() * 255) + 1;
	const b = Math.floor(Math.random() * 255) + 1;
	return `rgb(${r}, ${g}, ${b})`;
}

const dataURL =
	"https://docs.google.com/spreadsheets/d/e/2PACX-1vR1_wOYikhfMrmZ1IseS-EV5tjjs1OS7AS8NxZNjrbfWiPKY7f43t-2R3uLDS0L37Q9AEXVhLAs2KdS/pub?output=csv";
loadData(dataURL);
