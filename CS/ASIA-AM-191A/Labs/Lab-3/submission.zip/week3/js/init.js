// declare variables
const mapOptions = {
	zoom: 2,
	center: [40, -20],
};

// use the variables
const map = L.map("places-map").setView(mapOptions.center, mapOptions.zoom);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
	attribution:
		'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
}).addTo(map);

function createButtons(lat, lng, title, flag) {
	const newButton = document.createElement("button"); // adds a new button
	newButton.id = "button" + title; // gives the button a unique id
	newButton.innerHTML = `<img src="assets/${flag}.png" style="max-width:50px;object-fit:contain" />`; // gives the button a title
	newButton.setAttribute("lat", lat); // sets the latitude
	newButton.setAttribute("lng", lng); // sets the longitude
	newButton.addEventListener("click", function () {
		map.flyTo([lat, lng]); //this is the flyTo from Leaflet
	});
	document.getElementById("map-control").appendChild(newButton); //this adds the button to our page.
}

function addPopup(feature, layer) {
	layer.bindPopup(
		`<h2 style="width:200px">${feature.properties.name}</h2> <img src="${feature.properties.src}" style="max-width:200px;max-height:200px;object-fit:contain"}} />`
	);
	createButtons(
		feature.geometry.coordinates[1],
		feature.geometry.coordinates[0],
		feature.properties.flag,
		feature.properties.flag
	);
}

fetch("assets/map.geojson")
	.then((response) => {
		return response.json();
	})
	.then((data) => {
		// Basic Leaflet method to add GeoJSON data
		L.geoJSON(data, {
			onEachFeature: addPopup,
			pointToLayer: (feature, latlng) => {
				return L.circleMarker(latlng, {
					color: feature.properties.color,
				});
			},
		}).addTo(map);
	});
