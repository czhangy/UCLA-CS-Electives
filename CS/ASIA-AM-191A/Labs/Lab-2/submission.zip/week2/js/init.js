// declare variables
let zoomLevel = 2;
const mapCenter = [40, -20];

// use the variables
const map = L.map("the_map").setView(mapCenter, zoomLevel);

L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
	attribution:
		'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
}).addTo(map);

// create a function to add markers
function addMarker(lat, lng, title, message, src) {
	console.log(message);
	L.marker([lat, lng])
		.addTo(map)
		.bindPopup(
			`<h2>${title}</h2> <h3>${message}</h3> <img src="${src}" style="max-width:200px;max-height:200px;"}} />`
		);
	return message;
}

// use our marker functions
addMarker(
	22.096439,
	-159.526123,
	"Kaua'i",
	"Spring Break Trip",
	"https://bossfrog.com/wp-content/uploads/2017/02/Na-Pali-Coast-Kauai.jpg"
);
addMarker(
	38.0428,
	114.5143,
	"Shijiazhuang",
	"Dad's home",
	"https://images.chinahighlights.com/allpicture/2014/06/shijiazhuang43779d000e04_cut_800x500_66.jpg"
);
addMarker(
	41.3874,
	2.1686,
	"Barcelona",
	"Summer trip",
	"https://earth.esa.int/web/earth-watching/content/documents/257246/1608677/Barcelona.jpg"
);
addMarker(
	47.6062,
	-122.3321,
	"Seattle",
	"Summer work",
	"https://imageio.forbes.com/i-forbesimg/media/lists/places/seattle-wa_416x416.jpg?format=jpg&height=416&width=416&fit=bounds"
);
