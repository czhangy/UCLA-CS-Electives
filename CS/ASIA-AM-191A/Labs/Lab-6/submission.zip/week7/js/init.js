let latlng = [];
let markers = [];

const dataURL =
	"https://docs.google.com/spreadsheets/d/e/2PACX-1vR1_wOYikhfMrmZ1IseS-EV5tjjs1OS7AS8NxZNjrbfWiPKY7f43t-2R3uLDS0L37Q9AEXVhLAs2KdS/pub?output=csv";

let us = L.featureGroup();
let outsideUS = L.featureGroup();
const layers = {
	"Respondents born in the US": us,
	"Respondents born outside the US": outsideUS,
};
const layersArr = Object.values(layers);

const mapOptions = {
	zoom: 2,
	center: [40, -20],
};

const map = L.map("places-map").setView(mapOptions.center, mapOptions.zoom);
var basemap = L.tileLayer(
	"https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png",
	{
		attribution:
			'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
		subdomains: "abcd",
		maxZoom: 20,
	}
);
basemap.addTo(map);
L.control.layers(null, layers).addTo(map);

// Form data processing
function loadData(url) {
	Papa.parse(url, {
		header: true,
		download: true,
		complete: (results) => processData(results),
	});
}

function processData(results) {
	const allLayers = L.featureGroup([us, outsideUS]);
	results.data.forEach((data, i) => {
		addMarker(data);
		latlng.push({
			lat: data.lat,
			lng: data.lng,
		});
		createButtons(data.lat, data.lng, data["Location"], i);
	});
	layersArr.forEach((layer) => layer.addTo(map));
	map.fitBounds(allLayers.getBounds());
}

// Helpers
function createPopup(data, tag) {
	return `<h2 class="popup popup-title">Location: <span>${data["Location"]}</span></h2>
            <em class="popup popup-tag">${tag}</em>
            <hr />
            <h3 class="popup popup-subtitle">Do you follow any professional sports? If so, what got you into them?</h3>
            <p class="popup popup-content">${data["Do you follow any professional sports? If so, what got you into them?"]}</p>
            <h3 class="popup popup-subtitle">Do/did you play any organized sports? If so, what made you start playing?</h3>
            <p class="popup popup-content">${data["Do/did you play any organized sports? If so, what made you start playing?"]}</p>`;
}
function addMarker(data) {
	let marker;
	let circleOptions = {
		radius: 8,
		fillColor: "#ff7800",
		color: "#000",
		weight: 1,
		opacity: 1,
		fillOpacity: 0.5,
	};
	if (data["Did you grow up in the United States?"] === "Yes") {
		circleOptions.fillColor = "blue";
		marker = L.circleMarker([data.lat, data.lng], circleOptions).bindPopup(
			createPopup(data, "This respondent grew up in the US")
		);
		us.addLayer(marker);
	} else {
		circleOptions.fillColor = "green";
		marker = L.circleMarker([data.lat, data.lng], circleOptions).bindPopup(
			createPopup(data, "This respondent did not grow up in the US")
		);

		outsideUS.addLayer(marker);
	}
	markers.push(marker);
}

function createButtons(lat, lng, title, i) {
	const newButton = document.createElement("button");
	newButton.id = "button" + title;
	newButton.innerHTML = title;
	newButton.setAttribute("lat", lat);
	newButton.setAttribute("lng", lng);
	newButton.addEventListener("click", () => {
		map.flyTo([lat, lng]);
		markers[i].openPopup();
		window.scrollTo({ top: 80, behavior: "smooth" });
	});
	document.getElementById("buttons").appendChild(newButton);
}

loadData(dataURL);
